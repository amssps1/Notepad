﻿function Get-AdGroupForeignMembers
{
    param(
        [string]$group
    )

    $translatedMembers = @()

    $members = (Get-ADGroup $group -Properties member).member
    foreach($m in $members)
    {
        $orphan = $false
        $name = ""
        $sid = ""
        $dn = $([adsi]$("LDAP://$m")).DistinguishedName
        $ado = Get-ADObject -Identity $($dn)
        if($ado.Name -match "^S-\d-\d-\d\d")
        {
           
            try
            {
                $ntAccount = [System.Security.Principal.SecurityIdentifier] $ado.Name
                $name = $ntAccount.Translate([System.Security.Principal.NTAccount]).Value
                $sid = $ntAccount.Value
            }
            catch
            {
                $name = $ado.Name
                $orphan = $true
            }

        }
        else
        {
            $name = $ado.Name
        }

        $translatedMembers += [PSCustomObject] @{
            Name = $name
            SID = $sid
            Orphaned = $orphan
        }
    }

    Write-Output $translatedMembers
}

Get-AdGroupForeignMembers "GrpROTabularModEficEnc" | Export-CSV "C:\GrpROTabularModEficEnc.csv"
